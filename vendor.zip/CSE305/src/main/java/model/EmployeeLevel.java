package model;

/*
 * Note: these enum values have to match the databases exactly for JDBC to convert them from strings to enum value
 */
public enum EmployeeLevel {
    CustomerRep, Manager
}
