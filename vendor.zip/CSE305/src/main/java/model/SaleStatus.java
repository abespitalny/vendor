package model;

/**
 *
 * @author abraham
 */
public enum SaleStatus {
    Pending, Paid, Cancelled
}
